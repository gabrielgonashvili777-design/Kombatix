import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_IMAGES } from '../data/mmaData';
import {
  Shield,
  Swords,
  GitCommit,
  ArrowRight,
  ExternalLink,
  Info,
  CheckCircle2,
  Sparkles,
  Layers,
  Play
} from 'lucide-react';

const POSITION_VIDEOS: Record<string, { url: string; title: string }> = {
  'pos-closed-guard': { url: 'https://www.youtube.com/watch?v=KKxD5kdOkk0', title: 'BJJ Closed Guard Principles - Stephan Kesting' },
  'pos-open-guard': { url: 'https://www.youtube.com/watch?v=szAvJFvIzx4', title: 'Triangle Choke & Open Guard - Stephan Kesting' },
  'pos-half-guard': { url: 'https://www.youtube.com/watch?v=5ALqUk9uefk', title: 'Half Guard & Knee Shield Control - Stephan Kesting' },
  'pos-side-control': { url: 'https://www.youtube.com/watch?v=5ALqUk9uefk', title: 'Side Control Pressure & Escapes - Stephan Kesting' },
  'pos-mount': { url: 'https://www.youtube.com/watch?v=ygfnLjP6YQU', title: 'High-Level Sidemount & Mount Escape - Stephan Kesting' },
  'pos-back-control': { url: 'https://www.youtube.com/watch?v=176SLdBhj_A', title: 'A Rear Naked Choke Tutorial - Stephan Kesting' },
  'pos-turtle': { url: 'https://www.youtube.com/watch?v=QMVavyxjlNU', title: 'Turtle Defense & Sprawl Counter - Cary Kolat' }
};

export const BjjPositionExplorer: React.FC = () => {
  const { positions, selectedPositionId, setSelectedPositionId } = useApp();
  const [optionFilter, setOptionFilter] = useState<'all' | 'offensive' | 'defensive'>('all');

  const currentPosition =
    positions.find((p) => p.id === selectedPositionId) || positions[0];

  return (
    <div className="space-y-8">
      {/* Position Selector Strip */}
      <div className="overflow-x-auto pb-2 scrollbar-none">
        <div className="flex items-center gap-2 min-w-max">
          {positions.map((pos) => {
            const isSelected = pos.id === currentPosition.id;
            return (
              <button
                key={pos.id}
                onClick={() => setSelectedPositionId(pos.id)}
                className={`min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-950/50'
                    : 'bg-[#12151f] text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                }`}
              >
                <span>{pos.name}</span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                  isSelected ? 'bg-black/30 text-rose-100' : 'bg-slate-800 text-slate-400'
                }`}>
                  {pos.type.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Position Detail Hero */}
      <div className="bg-[#10131d] border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Position Media / Visual Demonstration */}
          <div className="lg:col-span-5 relative min-h-[260px] lg:min-h-[380px] bg-slate-950">
            <img
              src={APP_IMAGES.bjj}
              alt={currentPosition.name}
              className="w-full h-full object-cover filter contrast-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#10131d] via-[#10131d]/40 to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-[#10131d]" />

            <div className="absolute bottom-4 left-4 right-4 space-y-1">
              <div className="text-[11px] font-bold text-rose-400 uppercase tracking-widest flex items-center gap-2">
                <Layers className="w-3.5 h-3.5" />
                <span>Positional Hierarchy · {currentPosition.type}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading uppercase text-white">
                {currentPosition.name}
              </h2>
            </div>
          </div>

          {/* Core Mechanics & Principles */}
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
                {currentPosition.description}
              </p>

              {/* Direct YouTube Video Link */}
              {POSITION_VIDEOS[currentPosition.id] && (
                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <a
                    href={POSITION_VIDEOS[currentPosition.id].url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-md shadow-rose-950/40 transition-all active:scale-95"
                    title={`Watch straight on YouTube: ${POSITION_VIDEOS[currentPosition.id].title}`}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Watch {currentPosition.name} Video (Direct YouTube)</span>
                    <ExternalLink className="w-3.5 h-3.5 ml-0.5 text-rose-200" />
                  </a>
                </div>
              )}

              {/* Key Grappling Concepts */}
              <div className="space-y-2">
                <div className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <Info className="w-4 h-4" />
                  <span>Crucial Leverage Principles</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {currentPosition.keyConcepts.map((concept, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-[#161a26] border border-slate-800 text-xs text-slate-300 flex items-start gap-2"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                      <span>{concept}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Coach Pro Tip */}
              <div className="p-3.5 bg-rose-950/20 border border-rose-900/40 rounded-xl text-xs text-rose-200 leading-relaxed">
                <strong className="text-white uppercase tracking-wider mr-1">Fighter IQ:</strong>
                {currentPosition.proTip}
              </div>
            </div>

            {/* Direct Transition Pathways */}
            <div className="space-y-2 pt-2 border-t border-slate-800/80">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Connected Positional Transitions
              </div>
              <div className="flex flex-wrap gap-2">
                {currentPosition.transitions.map((trans, idx) => {
                  const target = positions.find((p) => p.id === trans.toPositionId);
                  if (!target) return null;
                  return (
                    <button
                      key={idx}
                      onClick={() => setSelectedPositionId(target.id)}
                      className="px-3 py-2 bg-[#161a26] hover:bg-rose-900/30 text-slate-200 hover:text-white border border-slate-800 hover:border-rose-700/60 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 group"
                    >
                      <span>To {target.name}</span>
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform text-rose-400" />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Offensive vs Defensive Options Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xl font-extrabold font-heading uppercase text-white tracking-wide">
              Technique Arsenal in {currentPosition.name}
            </h3>
            <div className="text-xs text-slate-400">Submissions, sweeps, passes, and high-percentage escapes</div>
          </div>

          {/* Filter segment */}
          <div className="flex items-center gap-1 p-1 bg-[#12151f] rounded-lg border border-slate-800">
            <button
              onClick={() => setOptionFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                optionFilter === 'all'
                  ? 'bg-rose-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Moves
            </button>
            <button
              onClick={() => setOptionFilter('offensive')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                optionFilter === 'offensive'
                  ? 'bg-rose-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Offense
            </button>
            <button
              onClick={() => setOptionFilter('defensive')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                optionFilter === 'defensive'
                  ? 'bg-rose-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Defense
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Offensive Options Column */}
          {(optionFilter === 'all' || optionFilter === 'offensive') && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-400">
                <Swords className="w-4 h-4" />
                <span>Offensive Options (Attacks & Sweeps)</span>
              </div>

              <div className="space-y-2.5">
                {currentPosition.offensiveOptions.map((opt, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-[#12151f] border border-slate-800 rounded-xl space-y-1.5 hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-sm text-white">{opt.name}</div>
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="px-2 py-0.5 rounded bg-rose-950/60 text-rose-400 border border-rose-900/40 font-semibold">
                          {opt.type}
                        </span>
                        <span className="text-slate-400">{opt.difficulty}</span>
                      </div>
                    </div>
                    <div className="text-xs text-slate-300 leading-relaxed">
                      {opt.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Defensive Options Column */}
          {(optionFilter === 'all' || optionFilter === 'defensive') && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-400">
                <Shield className="w-4 h-4" />
                <span>Defensive Escapes & Posture Restorations</span>
              </div>

              <div className="space-y-2.5">
                {currentPosition.defensiveOptions.map((opt, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-[#12151f] border border-slate-800 rounded-xl space-y-1.5 hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-sm text-white">{opt.name}</div>
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="px-2 py-0.5 rounded bg-blue-950/60 text-blue-400 border border-blue-900/40 font-semibold">
                          {opt.type}
                        </span>
                        <span className="text-slate-400">{opt.difficulty}</span>
                      </div>
                    </div>
                    <div className="text-xs text-slate-300 leading-relaxed">
                      {opt.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
