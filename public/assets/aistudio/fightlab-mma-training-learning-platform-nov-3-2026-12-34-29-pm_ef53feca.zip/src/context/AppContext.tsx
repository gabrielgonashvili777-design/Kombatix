import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Technique,
  BjjPosition,
  TrainingSession,
  ShadowboxAnalysis,
  UserProfile,
  Achievement,
  DailyChallenge,
  Discipline
} from '../types';
import {
  MMA_TECHNIQUES,
  BJJ_POSITIONS,
  INITIAL_ACHIEVEMENTS,
  INITIAL_DAILY_CHALLENGES
} from '../data/mmaData';

interface AppContextType {
  activeTab: 'home' | 'learn' | 'ai-coach' | 'training' | 'profile' | 'community';
  setActiveTab: (tab: 'home' | 'learn' | 'ai-coach' | 'training' | 'profile' | 'community') => void;
  learnSubTab: 'techniques' | 'positions';
  setLearnSubTab: (tab: 'techniques' | 'positions') => void;
  aiCoachSubTab: 'shadowbox' | 'assistant';
  setAiCoachSubTab: (tab: 'shadowbox' | 'assistant') => void;
  trainingSubTab: 'timer' | 'drills' | 'journal';
  setTrainingSubTab: (tab: 'timer' | 'drills' | 'journal') => void;
  
  // Techniques & Positions
  techniques: Technique[];
  positions: BjjPosition[];
  selectedTechnique: Technique | null;
  setSelectedTechnique: (tech: Technique | null) => void;
  activeVideoTechnique: Technique | null;
  setActiveVideoTechnique: (tech: Technique | null) => void;
  openTechniqueVideo: (tech: Technique) => void;
  selectedPositionId: string;
  setSelectedPositionId: (id: string) => void;
  recentlyViewedIds: string[];
  viewTechnique: (id: string) => void;
  
  // User & Progression
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  toggleFavoriteTechnique: (id: string) => void;
  toggleLearnedTechnique: (id: string) => void;
  
  // Training & Analysis
  trainingSessions: TrainingSession[];
  logTrainingSession: (session: Omit<TrainingSession, 'id' | 'date'>) => void;
  shadowboxHistory: ShadowboxAnalysis[];
  saveShadowboxAnalysis: (analysis: ShadowboxAnalysis) => void;
  
  // Challenges & Achievements
  challenges: DailyChallenge[];
  toggleChallengeComplete: (id: string) => void;
  achievements: Achievement[];
}

const DEFAULT_PROFILE: UserProfile = {
  id: 'usr-1',
  username: 'Alex Silva',
  nickname: 'The Iron Apex',
  rank: 'Amateur MMA (4-1-0)',
  avatarUrl: '/src/assets/images/hero_mma_fighter_1793692164782.jpg',
  preferredDiscipline: 'MMA',
  stance: 'Orthodox',
  experience: 'Intermediate',
  weightClass: 'Lightweight (155 lbs)',
  streakDays: 7,
  totalRounds: 42,
  favoriteTechniqueIds: ['box-cross', 'bjj-triangle', 'mt-low-kick', 'wrest-sprawl'],
  learnedTechniqueIds: ['box-jab', 'box-cross', 'mt-low-kick', 'bjj-closed-guard'],
  completedChallengeIds: ['dc-3'],
  weeklyRoundGoal: 20,
  privacy: 'public'
};

const INITIAL_SESSIONS: TrainingSession[] = [
  {
    id: 'ts-1',
    date: '2026-11-02',
    type: 'Timer',
    roundsCompleted: 5,
    durationMinutes: 25,
    discipline: 'MMA',
    notes: '5x5min championship rounds with 1m rest. Heavy focus on level change combinations into cage pressure.',
    rpe: 8
  },
  {
    id: 'ts-2',
    date: '2026-11-01',
    type: 'Shadowbox',
    roundsCompleted: 3,
    durationMinutes: 12,
    discipline: 'Boxing',
    notes: 'Slip cord footwork. High guard glued to cheek while throwing 3-2.',
    rpe: 7
  },
  {
    id: 'ts-3',
    date: '2026-10-30',
    type: 'BJJ Roll',
    roundsCompleted: 6,
    durationMinutes: 36,
    discipline: 'BJJ',
    notes: 'Positional rolling from side control bottom. Worked elbow-knee escapes and guard recovery.',
    rpe: 9
  }
];

const INITIAL_SHADOWBOX: ShadowboxAnalysis[] = [
  {
    id: 'sb-1',
    date: '2026-10-31',
    stance: 'Orthodox',
    overallScore: 84,
    categoryScores: {
      guard: 8.5,
      stance: 8.0,
      footwork: 8.5,
      balance: 9.0,
      punchTechnique: 8.5,
      headMovement: 7.5,
      coordination: 8.5
    },
    strengths: [
      'High rear hand guard anchored tightly during cross extension.',
      'Smooth pivot exits off the lead foot after throwing combinations.',
      'Excellent athletic hip torque and kinetic chain power transfer.'
    ],
    areasForImprovement: [
      'Head remains stationary on the centerline during 3-punch combinations.',
      'Lead hand occasionally dips 2 inches before launching the hook.',
      'Recovery step is slightly sluggish when exiting backward in straight line.'
    ],
    recommendations: [
      'Incorporate immediate slip or roll resets after every combination.',
      'Work with a slip cord 3 rounds daily to drill subconscious head movement.',
      'Practice lateral angle cuts rather than linear retreats.'
    ],
    recommendedDrills: ['Slip & Counter 1-2', 'Lead Pivot & Check Hook', 'Pendulum Step Reset'],
    summary: 'Strong technical baseline and crisp hand speed. Main focus should be head movement off center.',
    isAiEvaluated: true,
    evaluatorNote: 'Verified Gemini Biomechanics analysis'
  }
];

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'home' | 'learn' | 'ai-coach' | 'training' | 'profile' | 'community'>('home');
  const [learnSubTab, setLearnSubTab] = useState<'techniques' | 'positions'>('techniques');
  const [aiCoachSubTab, setAiCoachSubTab] = useState<'shadowbox' | 'assistant'>('shadowbox');
  const [trainingSubTab, setTrainingSubTab] = useState<'timer' | 'drills' | 'journal'>('timer');

  const [techniques] = useState<Technique[]>(MMA_TECHNIQUES);
  const [positions] = useState<BjjPosition[]>(BJJ_POSITIONS);
  const [selectedTechnique, setSelectedTechnique] = useState<Technique | null>(null);
  const [activeVideoTechnique, setActiveVideoTechnique] = useState<Technique | null>(null);
  const [selectedPositionId, setSelectedPositionId] = useState<string>('pos-closed-guard');

  const openTechniqueVideo = (tech: Technique) => {
    setActiveVideoTechnique(tech);
    setRecentlyViewedIds((prev) => {
      const next = [tech.id, ...prev.filter((i) => i !== tech.id)].slice(0, 8);
      return next;
    });
  };

  // Persistence for user profile
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('fightlab_profile');
      return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  });

  // Recently viewed techniques
  const [recentlyViewedIds, setRecentlyViewedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('fightlab_recent_techniques');
      return saved ? JSON.parse(saved) : ['box-jab', 'bjj-closed-guard', 'wrest-double-leg'];
    } catch {
      return ['box-jab', 'bjj-closed-guard', 'wrest-double-leg'];
    }
  });

  // Training Sessions
  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>(() => {
    try {
      const saved = localStorage.getItem('fightlab_sessions');
      return saved ? JSON.parse(saved) : INITIAL_SESSIONS;
    } catch {
      return INITIAL_SESSIONS;
    }
  });

  // Shadowbox History
  const [shadowboxHistory, setShadowboxHistory] = useState<ShadowboxAnalysis[]>(() => {
    try {
      const saved = localStorage.getItem('fightlab_shadowbox');
      return saved ? JSON.parse(saved) : INITIAL_SHADOWBOX;
    } catch {
      return INITIAL_SHADOWBOX;
    }
  });

  // Challenges
  const [challenges, setChallenges] = useState<DailyChallenge[]>(() => {
    try {
      const saved = localStorage.getItem('fightlab_challenges');
      return saved ? JSON.parse(saved) : INITIAL_DAILY_CHALLENGES;
    } catch {
      return INITIAL_DAILY_CHALLENGES;
    }
  });

  // Achievements
  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    try {
      const saved = localStorage.getItem('fightlab_achievements');
      return saved ? JSON.parse(saved) : INITIAL_ACHIEVEMENTS;
    } catch {
      return INITIAL_ACHIEVEMENTS;
    }
  });

  // Sync state to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('fightlab_profile', JSON.stringify(profile));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem('fightlab_recent_techniques', JSON.stringify(recentlyViewedIds));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [recentlyViewedIds]);

  useEffect(() => {
    try {
      localStorage.setItem('fightlab_sessions', JSON.stringify(trainingSessions));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [trainingSessions]);

  useEffect(() => {
    try {
      localStorage.setItem('fightlab_shadowbox', JSON.stringify(shadowboxHistory));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [shadowboxHistory]);

  useEffect(() => {
    try {
      localStorage.setItem('fightlab_challenges', JSON.stringify(challenges));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [challenges]);

  // View technique helper
  const viewTechnique = (id: string) => {
    const tech = techniques.find((t) => t.id === id);
    if (tech) {
      setSelectedTechnique(tech);
      setRecentlyViewedIds((prev) => {
        const next = [id, ...prev.filter((i) => i !== id)].slice(0, 8);
        return next;
      });
    }
  };

  // Toggle favorite
  const toggleFavoriteTechnique = (id: string) => {
    setProfile((prev) => {
      const exists = prev.favoriteTechniqueIds.includes(id);
      return {
        ...prev,
        favoriteTechniqueIds: exists
          ? prev.favoriteTechniqueIds.filter((t) => t !== id)
          : [...prev.favoriteTechniqueIds, id]
      };
    });
  };

  // Toggle mastered / learned
  const toggleLearnedTechnique = (id: string) => {
    setProfile((prev) => {
      const exists = prev.learnedTechniqueIds.includes(id);
      const nextLearned = exists
        ? prev.learnedTechniqueIds.filter((t) => t !== id)
        : [...prev.learnedTechniqueIds, id];

      // Update achievements
      setAchievements((achList) =>
        achList.map((ach) => {
          if (ach.id === 'ach-master-10') {
            const progress = nextLearned.length;
            return {
              ...ach,
              progress,
              unlocked: progress >= ach.maxProgress,
              unlockedDate: progress >= ach.maxProgress && !ach.unlocked ? new Date().toLocaleDateString() : ach.unlockedDate
            };
          }
          return ach;
        })
      );

      return {
        ...prev,
        learnedTechniqueIds: nextLearned
      };
    });
  };

  // Log workout
  const logTrainingSession = (sessionData: Omit<TrainingSession, 'id' | 'date'>) => {
    const newSession: TrainingSession = {
      ...sessionData,
      id: `ts-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    const nextSessions = [newSession, ...trainingSessions];
    setTrainingSessions(nextSessions);

    // Update profile stats
    setProfile((prev) => ({
      ...prev,
      totalRounds: prev.totalRounds + sessionData.roundsCompleted
    }));

    // Check achievement progress
    setAchievements((achList) =>
      achList.map((ach) => {
        if (ach.id === 'ach-train-10') {
          const progress = nextSessions.length;
          return {
            ...ach,
            progress,
            unlocked: progress >= 10,
            unlockedDate: progress >= 10 && !ach.unlocked ? new Date().toLocaleDateString() : ach.unlockedDate
          };
        }
        if (ach.id === 'ach-train-50') {
          const progress = nextSessions.length;
          return {
            ...ach,
            progress,
            unlocked: progress >= 50,
            unlockedDate: progress >= 50 && !ach.unlocked ? new Date().toLocaleDateString() : ach.unlockedDate
          };
        }
        return ach;
      })
    );
  };

  // Save shadowbox analysis
  const saveShadowboxAnalysis = (analysis: ShadowboxAnalysis) => {
    setShadowboxHistory((prev) => [analysis, ...prev]);
    // Unlock first AI analysis badge
    setAchievements((achList) =>
      achList.map((ach) => {
        if (ach.id === 'ach-first-ai-analysis') {
          return {
            ...ach,
            progress: 1,
            unlocked: true,
            unlockedDate: ach.unlockedDate || new Date().toLocaleDateString()
          };
        }
        return ach;
      })
    );
  };

  // Toggle challenge completion
  const toggleChallengeComplete = (id: string) => {
    setChallenges((prev) =>
      prev.map((c) => (c.id === id ? { ...c, completed: !c.completed } : c))
    );
  };

  // Update profile
  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...updates }));
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        learnSubTab,
        setLearnSubTab,
        aiCoachSubTab,
        setAiCoachSubTab,
        trainingSubTab,
        setTrainingSubTab,
        techniques,
        positions,
        selectedTechnique,
        setSelectedTechnique,
        activeVideoTechnique,
        setActiveVideoTechnique,
        openTechniqueVideo,
        selectedPositionId,
        setSelectedPositionId,
        recentlyViewedIds,
        viewTechnique,
        profile,
        updateProfile,
        toggleFavoriteTechnique,
        toggleLearnedTechnique,
        trainingSessions,
        logTrainingSession,
        shadowboxHistory,
        saveShadowboxAnalysis,
        challenges,
        toggleChallengeComplete,
        achievements
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
