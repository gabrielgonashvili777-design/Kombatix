import { Technique, BjjPosition, DailyChallenge, Achievement } from '../types';

export const APP_IMAGES = {
  hero: '/src/assets/images/hero_mma_fighter_1793692164782.jpg',
  striking: '/src/assets/images/striking_shadowboxing_1793692167036.jpg',
  bjj: '/src/assets/images/bjj_grappling_action_1793692167589.jpg',
  wrestling: '/src/assets/images/wrestling_takedown_1793692167647.jpg',
};

export const MMA_TECHNIQUES: Technique[] = [
  // ---------------- BOXING ----------------
  {
    id: 'box-jab',
    name: 'The Lead Jab',
    discipline: 'Boxing',
    category: 'Striking / Fundamentals',
    difficulty: 'Beginner',
    description: 'The cornerstone of combat striking. The jab establishes range, disrupts opponent rhythm, blinds vision for combinations, and scores points with minimal exposure.',
    steps: [
      {
        phase: 'Stance & Loading',
        instruction: 'Stand in athletic stance with weight distributed 50/50. Hands high, rear hand glued to your cheekbone, elbows tucked.',
        keyCue: 'Do not telegraph by pulling the hand back before extending.'
      },
      {
        phase: 'Extension & Rotation',
        instruction: 'Step forward slightly with lead foot while extending the lead fist straight out like a piston. Rotate fist 90 degrees right at the moment of impact so thumb faces downward-inward.',
        keyCue: 'Elevate lead shoulder to guard your chin from counter overhands.'
      },
      {
        phase: 'Snap & Retraction',
        instruction: 'Snap the punch with high velocity and instantly retract along the exact same linear trajectory back to your cheek.',
        keyCue: 'Never drop your lead hand to your chest upon recovery.'
      }
    ],
    commonMistakes: [
      { mistake: 'Flaring the lead elbow outwards like a chicken wing', fix: 'Keep elbow pointing straight down at the mat until the final rotation snap.' },
      { mistake: 'Dropping the rear hand while firing the jab', fix: 'Glue rear thumb to temple or cheekbone to prevent taking an overhand counter.' },
      { mistake: 'Overreaching past your center of gravity', fix: 'Take a micro 2-inch step with the lead foot instead of leaning your head forward.' }
    ],
    relatedTechniqueIds: ['box-cross', 'box-slip', 'box-lead-hook'],
    imageKey: 'striking',
    videoYoutubeId: 'ArQ50PXMCj4',
    externalResourceUrl: 'https://www.youtube.com/watch?v=ArQ50PXMCj4',
    externalResourceTitle: 'How to Throw the Perfect Jab in Boxing - Tony Jeffries',
    drillSuggestion: '3 rounds x 3 min: Double jab, lateral pivot, single jab to the body.'
  },
  {
    id: 'box-cross',
    name: 'Rear Cross (Straight Right/Left)',
    discipline: 'Boxing',
    category: 'Striking / Power Punches',
    difficulty: 'Beginner',
    description: 'The primary power straight punch. Driven from the rear foot, transferred through hips and core, delivering maximum linear kinetic energy while keeping chin guarded.',
    steps: [
      {
        phase: 'Initiation from Floor',
        instruction: 'Drive through the ball of the rear foot, pivoting rear heel outward as if extinguishing a cigarette.',
        keyCue: 'Power originates from foot friction and hip rotation, not the arm muscles.'
      },
      {
        phase: 'Torso Rotation & Extension',
        instruction: 'Rotate hips and torso 45 degrees, driving rear shoulder forward while extending the punch down the center pipe.',
        keyCue: 'Tuck chin into the rising rear shoulder collar.'
      },
      {
        phase: 'Recovery & Angle Exit',
        instruction: 'After impact, snap hand back to high guard and reset hips square or slip slightly off line.',
        keyCue: 'Do not stay parked in the pocket after committing weight.'
      }
    ],
    commonMistakes: [
      { mistake: 'Lifting rear foot off the mat entirely', fix: 'Keep the ball of the rear foot grounded to maintain base and balance.' },
      { mistake: 'Dropping lead hand while rotating', fix: 'Keep lead hand posted defensively in front of jaw.' }
    ],
    relatedTechniqueIds: ['box-jab', 'box-lead-hook', 'mma-feint-overhand'],
    imageKey: 'striking',
    videoYoutubeId: 'sK-6Ujp3KYY',
    externalResourceUrl: 'https://www.youtube.com/watch?v=sK-6Ujp3KYY',
    externalResourceTitle: 'How to Throw the Perfect Cross (Straight Right) - Tony Jeffries',
    drillSuggestion: '50 reps slow motion focusing on rear hip rotation, followed by 3x3min 1-2 combination drilling.'
  },
  {
    id: 'box-lead-hook',
    name: 'Lead Hook (Punch #3)',
    discipline: 'Boxing',
    category: 'Striking / Power Punches',
    difficulty: 'Intermediate',
    description: 'A devasating short-range hook designed to loop around the opponent guard and land flush on the jawline or temple, generating tremendous rotational torque.',
    steps: [
      {
        phase: 'Weight Shift & Load',
        instruction: 'Shift 60% of weight onto lead leg during a slip or following a rear cross to load the lead hip spring.',
        keyCue: 'Do not pull the hand back; let the torso load the strike.'
      },
      {
        phase: 'Horizontal Swing & Pivot',
        instruction: 'Pivot the lead foot 90 degrees on the ball, swinging lead arm in a tight horizontal arc with elbow bent at 90 degrees.',
        keyCue: 'Keep elbow, wrist, and shoulder on the exact same horizontal plane upon impact.'
      },
      {
        phase: 'Follow-Through & Shield',
        instruction: 'Stop the punch at opponent centerline without over-swinging, immediately returning lead glove to guard.',
        keyCue: 'Rear hand remains glued to cheek to block counters.'
      }
    ],
    commonMistakes: [
      { mistake: 'Over-swinging wildly past opponent centerline', fix: 'Lock elbow at 90 degrees and stop fist once it crosses the nose axis.' },
      { mistake: 'Throwing arm punch without pivoting lead foot', fix: 'Drive hip inward like slamming a car door.' }
    ],
    relatedTechniqueIds: ['box-jab', 'box-cross', 'box-slip'],
    imageKey: 'striking',
    videoYoutubeId: 'tyH4tYzgSqU',
    externalResourceUrl: 'https://www.youtube.com/watch?v=tyH4tYzgSqU',
    externalResourceTitle: 'The PROPER Way To Throw The Hook - Tony Jeffries',
    drillSuggestion: 'Practice 1-2-Lead Hook on heavy bag or shadowbox with 3-second pause at hip pivot.'
  },
  {
    id: 'box-uppercut',
    name: 'Rear Uppercut',
    discipline: 'Boxing',
    category: 'Striking / Inside Fighting',
    difficulty: 'Intermediate',
    description: 'A lethal vertical punch delivered in close range, driving upward between the opponent guard or punishing fighters who duck their heads forward.',
    steps: [
      {
        phase: 'Level Dip',
        instruction: 'Bend knees and dip rear shoulder slightly, lowering center of gravity rather than dropping hand.',
        keyCue: 'Never drop your hand below your belt line.'
      },
      {
        phase: 'Upward Leg Drive',
        instruction: 'Explode upward through legs and core, driving fist upward with palm facing your chest.',
        keyCue: 'Drive with leg extension; keep punch compact.'
      },
      {
        phase: 'Tight Return',
        instruction: 'Snap directly back to defensive shell as you stand tall.',
        keyCue: 'Lead hand must remain vigilant against incoming hooks.'
      }
    ],
    commonMistakes: [
      { mistake: 'Bowling ball motion winding up from hip', fix: 'Keep fist close to collarbone and lift with knee extension.' },
      { mistake: 'Leaning upper body backwards', fix: 'Keep head tucked forward with chin down.' }
    ],
    relatedTechniqueIds: ['box-lead-hook', 'box-cross', 'box-bob-weave'],
    imageKey: 'striking',
    videoYoutubeId: 'b33rufECWs0',
    externalResourceUrl: 'https://www.youtube.com/watch?v=b33rufECWs0',
    externalResourceTitle: 'How to Throw the Uppercut - Tony Jeffries',
    drillSuggestion: 'Slip rear -> Rear uppercut -> Lead hook -> Exit 45 degrees.'
  },
  {
    id: 'box-slip',
    name: 'The Slip & Centerline Evasion',
    discipline: 'Boxing',
    category: 'Defense / Head Movement',
    difficulty: 'Beginner',
    description: 'Evading straight punches by moving your head just inches off the central trajectory while loading your hips for immediate counter strikes.',
    steps: [
      {
        phase: 'Anticipation',
        instruction: 'Watch opponent chest and shoulder line rather than gloves to detect early telegraphs.',
        keyCue: 'Keep eyes on opponent throughout the movement.'
      },
      {
        phase: 'Lateral Crunch',
        instruction: 'Rotate shoulders and crunch obliques slightly so the oncoming punch grazes past your ear.',
        keyCue: 'Move only 2-3 inches—excessive movement wastes energy.'
      },
      {
        phase: 'Loaded Counter',
        instruction: 'Use the compressed hip spring to fire a counter cross or lead hook as you return.',
        keyCue: 'A slip without a counter is a wasted defensive opportunity.'
      }
    ],
    commonMistakes: [
      { mistake: 'Bending at the waist and staring at the mat', fix: 'Bend knees and crunch obliques; eyes remain locked forward.' },
      { mistake: 'Sliding straight backwards in a flat line', fix: 'Move diagonally forward-outside to cut angles.' }
    ],
    relatedTechniqueIds: ['box-bob-weave', 'box-shoulder-roll', 'box-jab'],
    imageKey: 'hero',
    videoYoutubeId: 'DOWc7NMSuEQ',
    externalResourceUrl: 'https://www.youtube.com/watch?v=DOWc7NMSuEQ',
    externalResourceTitle: 'How to SLIP Punches FASTER in Boxing - Tony Jeffries',
    drillSuggestion: 'Slip cord drill: 3 rounds walking along a taut string, slipping under each step.'
  },
  {
    id: 'box-bob-weave',
    name: 'Bob & Weave (The Roll)',
    discipline: 'Boxing',
    category: 'Defense / Head Movement',
    difficulty: 'Intermediate',
    description: 'Rolling underneath incoming hooks in a smooth U-shaped arc with the legs, resurfacing on the opponent blind flank.',
    steps: [
      {
        phase: 'Read Hook Arc',
        instruction: 'Identify the wide rotational path of opponent hook.',
        keyCue: 'Maintain hands glued to temples.'
      },
      {
        phase: 'Squat & Roll Underneath',
        instruction: 'Drop your hips 6 inches by bending knees and roll your torso under the punch in a smooth horseshoe motion.',
        keyCue: 'Do not bend your spine forward; keep back athletic.'
      },
      {
        phase: 'Ascend with Hook/Cross',
        instruction: 'Drive legs up on the outside of opponent punch, unloading with your own hook to body or head.',
        keyCue: 'Pop up like a coiled spring into position.'
      }
    ],
    commonMistakes: [
      { mistake: 'Looking down at feet during the roll', fix: 'Keep eyes up on the opponent chin level throughout.' },
      { mistake: 'Rolling too low into potential knee strikes (MMA danger)', fix: 'Keep dip minimal in MMA; only duck enough to clear gloves.' }
    ],
    relatedTechniqueIds: ['box-slip', 'box-lead-hook', 'box-pivot'],
    imageKey: 'striking',
    videoYoutubeId: 'DOWc7NMSuEQ',
    externalResourceUrl: 'https://www.youtube.com/watch?v=DOWc7NMSuEQ',
    externalResourceTitle: 'Boxing Head Movement & Rolling Under Hooks - Tony Jeffries',
    drillSuggestion: 'Slip-Slip-Roll-Cross combination shadowboxing rounds.'
  },
  {
    id: 'box-shoulder-roll',
    name: 'Shoulder Roll (Philly Shell Concept)',
    discipline: 'Boxing',
    category: 'Defense / Guard Positioning',
    difficulty: 'Advanced',
    description: 'A sophisticated defensive stance where the lead shoulder is elevated to deflect straight punches while the rear hand catches hooks and counters instantly.',
    steps: [
      {
        phase: 'Posture Alignment',
        instruction: 'Lead shoulder raised high to cover chin, lead arm draped across stomach to protect body, rear hand glued to right cheek.',
        keyCue: 'Angle body 60 degrees away from opponent centerline.'
      },
      {
        phase: 'Deflective Twist',
        instruction: 'Rotate lead shoulder into oncoming cross or jab so impact glides harmlessly off the shoulder cap.',
        keyCue: 'Relax upper shoulder muscles to let force glance off.'
      },
      {
        phase: 'Spring Counter',
        instruction: 'Uncoil rear cross or check hook immediately as the opponent punch skids away.',
        keyCue: 'Time your shot at the exact climax of their extension.'
      }
    ],
    commonMistakes: [
      { mistake: 'Attempting Philly shell against high kicks in MMA without modification', fix: 'Use high guard if head kicks or elbows are in range.' },
      { mistake: 'Leaving lead chin exposed by dropping shoulder', fix: 'Shoulder must tuck tightly beneath the ear.' }
    ],
    relatedTechniqueIds: ['box-slip', 'box-cross'],
    imageKey: 'hero',
    videoYoutubeId: 'FSVcmMd9bR4',
    externalResourceUrl: 'https://www.youtube.com/watch?v=FSVcmMd9bR4',
    externalResourceTitle: 'Philly Shell & Shoulder Roll Fundamentals - Tony Jeffries',
    drillSuggestion: 'Partner drill or mirror drill catching straight shots with lead shoulder deflection.'
  },
  {
    id: 'box-pivot',
    name: 'Lead Foot Pivot & Angle Cut',
    discipline: 'Boxing',
    category: 'Footwork / Ring Craft',
    difficulty: 'Intermediate',
    description: 'Nailing the lead foot into the canvas and swinging the rear leg 45 to 90 degrees to escape ropes/cage pressure and create open striking avenues.',
    steps: [
      {
        phase: 'Anchor Lead Foot',
        instruction: 'Place ball of lead foot firmly while opponent rushes in straight line.',
        keyCue: 'Treat lead foot like a compass needle pivot point.'
      },
      {
        phase: 'Swing Rear Foot',
        instruction: 'Sweep rear foot laterally 90 degrees while maintaining balance and guard.',
        keyCue: 'Your head moves completely off their attack runway.'
      },
      {
        phase: 'Establish New Stance',
        instruction: 'Catch your weight instantly in your fighting stance and fire cross or check hook.',
        keyCue: 'Be ready to strike before opponent turns to face you.'
      }
    ],
    commonMistakes: [
      { mistake: 'Crossing feet during pivot', fix: 'Swing rear leg behind in a clean arc; never cross legs.' },
      { mistake: 'Losing high guard while turning', fix: 'Hands remain glued to cheekbones.' }
    ],
    relatedTechniqueIds: ['box-lead-hook', 'mma-cage-cutoff'],
    imageKey: 'striking',
    videoYoutubeId: 'KODMvHfTfX0',
    externalResourceUrl: 'https://www.youtube.com/watch?v=KODMvHfTfX0',
    externalResourceTitle: 'Boxing Basics: How to Move & Pivot - Tony Jeffries',
    drillSuggestion: 'Agility cone footwork: Step jab, pivot 90 degrees around cone, fire 2-3.'
  },

  // ---------------- MUAY THAI ----------------
  {
    id: 'mt-low-kick',
    name: 'Rear Low Kick (Leg Chopper)',
    discipline: 'Muay Thai',
    category: 'Kicks / Lower Body',
    difficulty: 'Beginner',
    description: 'One of the most destructive strikes in combat sports. Swung like a baseball bat into opponent quadricep or calf to compromise mobility, base, and takedown drive.',
    steps: [
      {
        phase: 'Step 45 Degrees',
        instruction: 'Step lead foot 45 degrees outside opponent lead leg, opening lead hip for full rotation.',
        keyCue: 'Step off the centerline to clear incoming straight punches.'
      },
      {
        phase: 'Swing & Hip Turn',
        instruction: 'Turn rear hip completely over so belly button faces opposite wall. Strike with hard lower third of tibia shin bone.',
        keyCue: 'Swing rear arm down for counterbalance while lead hand shields face.'
      },
      {
        phase: 'Impact & Snap Reset',
        instruction: 'Chop through the leg muscle like cutting down a tree, rebounding leg immediately into stance.',
        keyCue: 'Aim through the target, not to the surface.'
      }
    ],
    commonMistakes: [
      { mistake: 'Kicking with the fragile foot/instep instead of shin', fix: 'Condition and land exclusively with the dense lower tibia bone.' },
      { mistake: 'Dropping opposite hand, exposing head to counter hook', fix: 'Glue lead hand to temple or post onto opponent forehead.' }
    ],
    relatedTechniqueIds: ['mt-switch-kick', 'mt-teep', 'box-jab'],
    imageKey: 'striking',
    videoYoutubeId: 'zBMr-FsmxqU',
    externalResourceUrl: 'https://www.youtube.com/watch?v=zBMr-FsmxqU',
    externalResourceTitle: 'Muay Thai Stance & Low Kick Mechanics - Sean Fagan',
    drillSuggestion: '100 low kicks on heavy bag alternating with check defense.'
  },
  {
    id: 'mt-switch-kick',
    name: 'Lead Switch Kick (Body / Head)',
    discipline: 'Muay Thai',
    category: 'Kicks / Midsection',
    difficulty: 'Intermediate',
    description: 'A lightning-fast kick targeting opponent liver, ribs, or neck by micro-switching feet to transform lead leg into a rear power strike with zero delay.',
    steps: [
      {
        phase: 'The Micro-Switch',
        instruction: 'Hop slightly and switch stance in place: lead foot slides back, rear foot steps 45 degrees forward.',
        keyCue: 'Stay low and compact; do not jump high.'
      },
      {
        phase: 'Shin Elevation',
        instruction: 'Rotate hips violently and drive left shin up into opponent right ribs or head.',
        keyCue: 'Turn hip completely over so shin lands horizontally.'
      },
      {
        phase: 'Return to Orthodox',
        instruction: 'Retract leg cleanly and land back into natural orthodox stance.',
        keyCue: 'Maintain balanced posture to check any counter kicks.'
      }
    ],
    commonMistakes: [
      { mistake: 'Jumping high in the air during the switch', fix: 'Keep feet scraping the canvas for maximum quickness.' },
      { mistake: 'Failing to turn hips over, resulting in weak slapping kick', fix: 'Point knee and hip directly into opponent ribs.' }
    ],
    relatedTechniqueIds: ['mt-low-kick', 'mt-teep'],
    imageKey: 'striking',
    videoYoutubeId: 'zBMr-FsmxqU',
    externalResourceUrl: 'https://www.youtube.com/watch?v=zBMr-FsmxqU',
    externalResourceTitle: 'Lead Switch Kick Technique & Power - Sean Fagan',
    drillSuggestion: 'Switch kick speed ladder: 20 rapid switch kicks on pads.'
  },
  {
    id: 'mt-teep',
    name: 'Front Teep (The Push Kick)',
    discipline: 'Muay Thai',
    category: 'Kicks / Distance Control',
    difficulty: 'Beginner',
    description: 'The martial arts equivalent of the jab with the leg. Used to impale the opponent midsection, push them back, disrupt blitz attacks, and manage range.',
    steps: [
      {
        phase: 'Chamber Knee',
        instruction: 'Lift lead knee high to chest level like a coiled pistol.',
        keyCue: 'Knee points directly at target before extending.'
      },
      {
        phase: 'Hip Thrust Extension',
        instruction: 'Thrust hips forward aggressively, pushing ball of foot into opponent sternum or bladder.',
        keyCue: 'Flex toes back; strike with ball of foot.'
      },
      {
        phase: 'Snap Chamber Back',
        instruction: 'Pull foot straight back to knee chamber before dropping down into stance.',
        keyCue: 'Prevents opponent from catching the kicking leg.'
      }
    ],
    commonMistakes: [
      { mistake: 'Leaving kicking leg floating out to get caught and taken down', fix: 'Retract twice as fast as you extend.' },
      { mistake: 'Kicking with flat foot or toes', fix: 'Curl toes backward to pierce with the rigid ball of foot.' }
    ],
    relatedTechniqueIds: ['mt-low-kick', 'wrest-sprawl'],
    imageKey: 'striking',
    videoYoutubeId: 'elLMNnEAfLk',
    externalResourceUrl: 'https://www.youtube.com/watch?v=elLMNnEAfLk',
    externalResourceTitle: 'How to Throw a Powerful Teep Push Kick - Sean Fagan',
    drillSuggestion: 'Partner teep sparring: Intercept partner forward advances with timed teeps.'
  },
  {
    id: 'mt-spear-knee',
    name: 'Spear Knee (Straight Knee Strike)',
    discipline: 'Muay Thai',
    category: 'Knees / Midsection',
    difficulty: 'Intermediate',
    description: 'A forward-thrusting knee designed to pierce through opponent guard and fracture ribs or knock the wind out of their diaphragm.',
    steps: [
      {
        phase: 'Post or Collar Grip',
        instruction: 'Post lead hand on opponent forehead or neck to pull them slightly forward.',
        keyCue: 'Control opponent head to limit their ability to retreat.'
      },
      {
        phase: 'Hip Drive & Toe Point',
        instruction: 'Thrust hips forward like a spear, pointing toes downward to sharpen the kneecap point.',
        keyCue: 'Lean upper body slightly back to counterbalance powerful hip thrust.'
      },
      {
        phase: 'Step-Down Reset',
        instruction: 'Step knee straight down into strong base.',
        keyCue: 'Immediately frame against counter takedowns.'
      }
    ],
    commonMistakes: [
      { mistake: 'Lifting knee upward instead of thrusting forward', fix: 'Drive hips forward horizontally into opponent abdomen.' },
      { mistake: 'Leaving toes relaxed', fix: 'Point toes down to make patella bone razor sharp.' }
    ],
    relatedTechniqueIds: ['mt-clinch-plum', 'mt-elbow'],
    imageKey: 'hero',
    videoYoutubeId: 'EKFytLBP-Iw',
    externalResourceUrl: 'https://www.youtube.com/watch?v=EKFytLBP-Iw',
    externalResourceTitle: 'Muay Thai Clinch & Knee Strike Mechanics - Sean Fagan',
    drillSuggestion: 'Heavy bag clinch knee drills: 50 thrusting knees with hip pop.'
  },
  {
    id: 'mt-elbow',
    name: 'Horizontal Cutting Elbow',
    discipline: 'Muay Thai',
    category: 'Elbows / Close Quarters',
    difficulty: 'Intermediate',
    description: 'A razor-sharp close-range strike utilizing the olecranon bone point to slice skin over eyebrows or knock out opponents inside the pocket.',
    steps: [
      {
        phase: 'Pocket Entry',
        instruction: 'Close distance safely behind a jab or inside a collar tie clinch.',
        keyCue: 'Keep opposite hand raised in tight telephone shield.'
      },
      {
        phase: 'Thumb to Chest & Rotate',
        instruction: 'Bring thumb to collarbone/chest to lock forearm tight, rotating torso and slicing elbow horizontally across jaw.',
        keyCue: 'Rotate shoulders as if throwing a tight hook.'
      },
      {
        phase: 'Reset or Follow',
        instruction: 'Loop around and recover guard or follow with an immediate rear elbow.',
        keyCue: 'Stay compact to avoid being caught on the inside.'
      }
    ],
    commonMistakes: [
      { mistake: 'Throwing elbow from wide distance where it misses', fix: 'Only throw when chest-to-chest or inside 18 inches.' },
      { mistake: 'Opening hand and loosening forearm tension', fix: 'Thumb tight to collarbone locks the bone structure rigid.' }
    ],
    relatedTechniqueIds: ['mt-clinch-plum', 'mt-spear-knee'],
    imageKey: 'striking',
    videoYoutubeId: '2nViNSWq0cw',
    externalResourceUrl: 'https://www.youtube.com/watch?v=2nViNSWq0cw',
    externalResourceTitle: 'Muay Thai Clinch Trapping & Elbow Technique - Sean Fagan',
    drillSuggestion: 'Shadowbox combinations: 1-2 -> Level-change entry -> Horizontal elbow.'
  },
  {
    id: 'mt-clinch-plum',
    name: 'Muay Thai Clinch (Double Collar Tie / Plum)',
    discipline: 'Muay Thai',
    category: 'Clinch / Control',
    difficulty: 'Intermediate',
    description: 'Controlling opponent crown and neck with both hands cupped behind head to steer their posture down into devastating knee strikes and elbow sweeps.',
    steps: [
      {
        phase: 'Crown Grip Acquisition',
        instruction: 'Swim arms inside opponent guard. Cup hands one over the other behind the highest point of crown.',
        keyCue: 'Never interlace fingers; stack palms over crown.'
      },
      {
        phase: 'Elbow Compression',
        instruction: 'Squeeze forearms against opponent collarbones, pinning their head to your chest.',
        keyCue: 'Break their spine alignment so their eyes point down at mat.'
      },
      {
        phase: 'Steer & Knee',
        instruction: 'Pull head down and rotate their torso while driving knees into ribs.',
        keyCue: 'Off-balance opponent continuously so they cannot swing power punches.'
      }
    ],
    commonMistakes: [
      { mistake: 'Interlacing fingers (vulnerable to broken fingers)', fix: 'Stack palm on back of opposite hand.' },
      { mistake: 'Allowing opponent to swim underhooks inside', fix: 'Keep elbows tight together in the center.' }
    ],
    relatedTechniqueIds: ['mt-spear-knee', 'wrest-underhook'],
    imageKey: 'hero',
    videoYoutubeId: 'EKFytLBP-Iw',
    externalResourceUrl: 'https://www.youtube.com/watch?v=EKFytLBP-Iw',
    externalResourceTitle: 'Muay Thai Clinch Positioning & Escapes - Sean Fagan',
    drillSuggestion: 'Clinch swimming rounds: 3x3min battling for inside collar tie control.'
  },

  // ---------------- WRESTLING ----------------
  {
    id: 'wrest-level-change',
    name: 'Level Change & Penetration Step',
    discipline: 'Wrestling',
    category: 'Takedowns / Fundamentals',
    difficulty: 'Beginner',
    description: 'The foundational athletic mechanism behind all leg takedowns. Dropping hips without bending spine and shooting the lead knee deep between opponent feet.',
    steps: [
      {
        phase: 'Level Change',
        instruction: 'Lower your center of gravity by bending at knees and ankles while keeping chest tall and eyes up.',
        keyCue: 'Never bend at waist; maintain strong erect spinal posture.'
      },
      {
        phase: 'Penetration Step',
        instruction: 'Step lead foot deeply between opponent legs, sliding lead knee onto canvas mat like a spear.',
        keyCue: 'Trail leg follows instantly to provide explosive forward propulsion.'
      },
      {
        phase: 'Head Up & Drive',
        instruction: 'Drive head and forehead into opponent chest or sternum while wrapping both legs.',
        keyCue: 'Head in the chest controls their spine and neutralizes counter guillotines.'
      }
    ],
    commonMistakes: [
      { mistake: 'Ducking head down towards opponent waist (walks right into guillotine choke)', fix: 'Keep chin up, neck packed, forehead buried into sternum.' },
      { mistake: 'Shooting from too far outside without setting up with strikes', fix: 'Touch opponent lead hand before shooting to ensure in range.' }
    ],
    relatedTechniqueIds: ['wrest-double-leg', 'wrest-single-leg', 'mma-feint-overhand'],
    imageKey: 'wrestling',
    videoYoutubeId: 'vFvl1tdr8l4',
    externalResourceUrl: 'https://www.youtube.com/watch?v=vFvl1tdr8l4',
    externalResourceTitle: 'Wrestling Level Change & Penetration Step - Cary Kolat',
    drillSuggestion: '50 continuous penetration steps across the mat, popping back to stance.'
  },
  {
    id: 'wrest-double-leg',
    name: 'Blast Double-Leg Takedown',
    discipline: 'Wrestling',
    category: 'Takedowns / Core',
    difficulty: 'Intermediate',
    description: 'Explosive takedown driving straight through opponent hips, cup-gripping behind both knees, and turning the corner to slam opponent to the mat.',
    steps: [
      {
        phase: 'Jab Setup & Level Drop',
        instruction: 'Throw jab to lift opponent hands, instantly changing levels beneath their eye line.',
        keyCue: 'Shoot under their punches when their hips are stationary.'
      },
      {
        phase: 'Deep Drive & Knee Wrap',
        instruction: 'Shoot penetration step between their legs, driving forehead into chest while wrapping arms behind knee joints.',
        keyCue: 'Pull their knees towards you as your forehead drives their chest away.'
      },
      {
        phase: 'Turn the Corner',
        instruction: 'Step trail foot out 45 degrees, angle your hips, and drive diagonally to dump them onto their back into side control.',
        keyCue: 'Never stay underneath their full guard; cut the angle immediately.'
      }
    ],
    commonMistakes: [
      { mistake: 'Stopping forward drive upon contact', fix: 'Keep legs pumping forward until opponent touches canvas.' },
      { mistake: 'Reaching with arms before hips arrive', fix: 'Hips must penetrate past opponent knees.' }
    ],
    relatedTechniqueIds: ['wrest-single-leg', 'wrest-sprawl', 'bjj-side-control'],
    imageKey: 'wrestling',
    videoYoutubeId: 'vFvl1tdr8l4',
    externalResourceUrl: 'https://www.youtube.com/watch?v=vFvl1tdr8l4',
    externalResourceTitle: 'Double Leg Head Drive - Cary Kolat Wrestling Moves',
    drillSuggestion: 'Double leg repetitions against wall pads and live mat drills.'
  },
  {
    id: 'wrest-single-leg',
    name: 'Single-Leg Takedown (Run the Pipe)',
    discipline: 'Wrestling',
    category: 'Takedowns / Core',
    difficulty: 'Intermediate',
    description: 'Isolating one of opponent legs between your thighs, lifting it onto your hip shelf, and circling backwards to force them to the floor.',
    steps: [
      {
        phase: 'Angle Entry',
        instruction: 'Snatch opponent lead leg, wrapping both hands around calf/thigh with forehead pressed into their ribs.',
        keyCue: 'Keep head on the inside of their chest to prevent head locks.'
      },
      {
        phase: 'Shelf the Leg',
        instruction: 'Elevate opponent leg, pinching it between your legs or hoisting it onto your hip.',
        keyCue: 'Posture tall with back straight to support weight.'
      },
      {
        phase: 'Run the Pipe Finish',
        instruction: 'Take a deep back step in a circular motion like pulling a heavy rug, dropping opponent to hip.',
        keyCue: 'Rotate in the direction of their captured heel.'
      }
    ],
    commonMistakes: [
      { mistake: 'Leaving head on the outside (exposes to guillotine or switch counter)', fix: 'Bury head tight into opponent ribcage or sternum.' },
      { mistake: 'Bending back instead of using leg power', fix: 'Squat and stand tall with athletic glute drive.' }
    ],
    relatedTechniqueIds: ['wrest-double-leg', 'wrest-sprawl', 'bjj-half-guard'],
    imageKey: 'wrestling',
    videoYoutubeId: 'mRIDD2zoKJ8',
    externalResourceUrl: 'https://www.youtube.com/watch?v=mRIDD2zoKJ8',
    externalResourceTitle: 'Single Leg Takedown Breakdown - Cary Kolat / Stephan Kesting',
    drillSuggestion: 'Single leg chain drill: High single -> Run the pipe -> Step through.'
  },
  {
    id: 'wrest-sprawl',
    name: 'The Sprawl & Cross-Face Defense',
    discipline: 'Wrestling',
    category: 'Defense / Takedown Defense',
    difficulty: 'Beginner',
    description: 'The primary defense against all leg takedowns. Throwing your hips backwards and downward, driving massive hip weight onto opponent neck and shoulders.',
    steps: [
      {
        phase: 'Instant Reaction',
        instruction: 'As opponent changes level, drop your hands to frame on their shoulders or head.',
        keyCue: 'Fight their head before their hands touch your legs.'
      },
      {
        phase: 'Kick Hips Back & Mat Drive',
        instruction: 'Violently kick both legs straight back, slamming your pelvic bone into the back of their neck/upper back.',
        keyCue: 'Hips heavy like an anvil; shoelaces flat on the mat.'
      },
      {
        phase: 'Cross-Face & Spin Behind',
        instruction: 'Drive forearm across opponent nose/cheek (cross-face) to turn their head away, spinning behind to take the back.',
        keyCue: 'Where the head goes, the body follows.'
      }
    ],
    commonMistakes: [
      { mistake: 'Hesitating and letting opponent lock hands around knees', fix: 'Sprawl the instant their level drops; do not wait for contact.' },
      { mistake: 'Staying on your knees instead of driving hip weight down', fix: 'Legs must be completely extended back with hips glued to their head.' }
    ],
    relatedTechniqueIds: ['wrest-double-leg', 'bjj-turtle', 'mma-cage-wallwalk'],
    imageKey: 'wrestling',
    videoYoutubeId: 'QMVavyxjlNU',
    externalResourceUrl: 'https://www.youtube.com/watch?v=QMVavyxjlNU',
    externalResourceTitle: 'Best Sprawl Position To Stop Leg Attack - Cary Kolat',
    drillSuggestion: 'Sprawl reflex drill: Partner claps hands or feints shot, explosive sprawl reset 20 reps.'
  },
  {
    id: 'wrest-underhook',
    name: 'Underhook Control & Front Headlock',
    discipline: 'Wrestling',
    category: 'Clinch / Control',
    difficulty: 'Intermediate',
    description: 'Pummeling an arm under opponent armpit to control their shoulder girdle, posture, and off-balance them for throws, cage pins, or snapdowns.',
    steps: [
      {
        phase: 'Pummel Inside',
        instruction: 'Dig your forearm up through opponent armpit, gripping over their far shoulder with high elbow.',
        keyCue: 'Elbow must be higher than your shoulder to control leverage.'
      },
      {
        phase: 'Head Position Battle',
        instruction: 'Bury your forehead under their chin or into their temple to block their forward gaze.',
        keyCue: 'Head position wins 80% of wrestling clinches.'
      },
      {
        phase: 'Snapdown or Knee Pick',
        instruction: 'Jack up underhook to open their stance, or snap their head down into front headlock.',
        keyCue: 'Threaten both upper body throws and low leg picks simultaneously.'
      }
    ],
    commonMistakes: [
      { mistake: 'Weak low elbow that allows opponent to overhook/whizzer you easily', fix: 'Jack elbow up towards ceiling to keep their shoulder pinned.' },
      { mistake: 'Staying squared up in front of them', fix: 'Angle your torso 45 degrees into their underhook side.' }
    ],
    relatedTechniqueIds: ['mt-clinch-plum', 'mma-cage-wallwalk', 'bjj-turtle'],
    imageKey: 'wrestling',
    videoYoutubeId: '5IHQpcz-Qq8',
    externalResourceUrl: 'https://www.youtube.com/watch?v=5IHQpcz-Qq8',
    externalResourceTitle: 'Underhook Control & Front Headlock - Shane Fazen',
    drillSuggestion: 'Pummeling flow: 5-minute continuous inside underhook pummeling with partner.'
  },

  // ---------------- BRAZILIAN JIU-JITSU ----------------
  {
    id: 'bjj-closed-guard',
    name: 'Closed Guard Fundamentals',
    discipline: 'BJJ',
    category: 'Guard / Ground Combat',
    difficulty: 'Beginner',
    description: 'Bottom practitioner wraps their legs completely around the opponent torso, locking ankles behind the lower back. Neutral in point scoring, but heavily offensive for bottom fighter.',
    steps: [
      {
        phase: 'Ankle Lock & Hip Clamping',
        instruction: 'Lock ankles behind opponent lower back, squeezing adductor thighs tight around their ribs.',
        keyCue: 'Keep hips light and mobile rather than resting flat on the mat.'
      },
      {
        phase: 'Posture Breakdown',
        instruction: 'Pull knees to chest while pulling opponent head/collar down with both hands to break their erect spine.',
        keyCue: 'An opponent without posture cannot land effective ground-and-pound or pass.'
      },
      {
        phase: 'Overhook & Attack Threat',
        instruction: 'Wrap an overhook around their arm and control far wrist, opening pathways for kimuras, armbars, and sweeps.',
        keyCue: 'Never stay inactive on your back; constantly off-balance them.'
      }
    ],
    commonMistakes: [
      { mistake: 'Allowing opponent to post hands on your chest and stand tall', fix: 'Use knee pulls to constantly collapse their posting arms.' },
      { mistake: 'Crossing ankles loosely down around their hips where you get stacked', fix: 'Keep ankles locked high near their kidney line.' }
    ],
    relatedTechniqueIds: ['bjj-armbar', 'bjj-triangle', 'bjj-half-guard'],
    imageKey: 'bjj',
    videoYoutubeId: 'KKxD5kdOkk0',
    externalResourceUrl: 'https://www.youtube.com/watch?v=KKxD5kdOkk0',
    externalResourceTitle: 'BJJ Closed Guard Principles - Stephan Kesting',
    drillSuggestion: 'Positional sparring: Top player tries to break guard, bottom player attacks sweeps/subs.'
  },
  {
    id: 'bjj-armbar',
    name: 'Straight Armbar from Guard',
    discipline: 'BJJ',
    category: 'Submissions / Joint Locks',
    difficulty: 'Beginner',
    description: 'A classic hyperextension submission against opponent elbow joint, isolating the arm between thighs and driving hips upward into the fulcrum.',
    steps: [
      {
        phase: 'Isolate & Pull Arm Across',
        instruction: 'Secure two-on-one control on opponent right wrist and tricep, pulling the arm across your centerline.',
        keyCue: 'Opponent elbow must cross your navel line.'
      },
      {
        phase: 'High Guard & Perpendicular Pivot',
        instruction: 'Place left foot on opponent hip, pivot body 90 degrees perpendicular, and clamp right leg high over their shoulder blade.',
        keyCue: 'Bite down hard with calves to prevent opponent from stacking.'
      },
      {
        phase: 'Leg Over Head & Hip Extension',
        instruction: 'Swing left leg cleanly over opponent face. Pinch knees together, hold wrist with thumbs pointing up, and gently lift hips.',
        keyCue: 'Thumb must point towards ceiling for proper elbow fulcrum.'
      }
    ],
    commonMistakes: [
      { mistake: 'Spreading knees apart while lifting hips', fix: 'Pinch knees tightly together to prevent elbow slip.' },
      { mistake: 'Allowing opponent to stack you and smash your neck', fix: 'Push opponent face away with your leg and scoop their far leg to sweep.' }
    ],
    relatedTechniqueIds: ['bjj-closed-guard', 'bjj-triangle'],
    imageKey: 'bjj',
    videoYoutubeId: 'AV9NorNMWl4',
    externalResourceUrl: 'https://www.youtube.com/watch?v=AV9NorNMWl4',
    externalResourceTitle: 'Armbar from Guard: 3 Most Common Errors - Stephan Kesting',
    drillSuggestion: 'Armbar rotation reps: 20 repetitions each side smoothly without pausing.'
  },
  {
    id: 'bjj-triangle',
    name: 'The Triangle Choke (Sankaku-Jime)',
    discipline: 'BJJ',
    category: 'Submissions / Strangles',
    difficulty: 'Intermediate',
    description: 'Forming a figure-four lock with your legs around opponent head and one arm, compressing carotid arteries with their own shoulder and your inner thigh.',
    steps: [
      {
        phase: 'One-In, One-Out Control',
        instruction: 'Push one opponent arm down to their belly while pulling other arm forward over your shoulder.',
        keyCue: 'Ensure one arm is trapped inside and one arm is outside the guard.'
      },
      {
        phase: 'Lock Figure-Four',
        instruction: 'Shoot hips high and clamp ankles behind their neck. Pull trapped arm across your chest.',
        keyCue: 'Arm across chest ensures their own shoulder chokes their carotid artery.'
      },
      {
        phase: 'Angle Cut & Squeeze',
        instruction: 'Underhook their free arm or leg to pivot 45 degrees, lock shin under knee pit, and squeeze knees together while pulling head down.',
        keyCue: 'Cutting an angle eliminates neck space and finishes the choke with minimal effort.'
      }
    ],
    commonMistakes: [
      { mistake: 'Locking over your own foot instead of your shin (breaks your own ankle)', fix: 'Adjust hips so your shin lies flat under your opposite knee crease.' },
      { mistake: 'Leaving trapped arm on the wrong side', fix: 'Cross their arm firmly across your torso before locking.' }
    ],
    relatedTechniqueIds: ['bjj-closed-guard', 'bjj-armbar'],
    imageKey: 'bjj',
    videoYoutubeId: 'szAvJFvIzx4',
    externalResourceUrl: 'https://www.youtube.com/watch?v=szAvJFvIzx4',
    externalResourceTitle: 'How to Escape & Finish Triangle Choke - Stephan Kesting',
    drillSuggestion: 'Triangle setup flow: Overhook to wrist shove to triangle catch.'
  },
  {
    id: 'bjj-half-guard',
    name: 'Half Guard & Knee Shield Control',
    discipline: 'BJJ',
    category: 'Guard / Retention',
    difficulty: 'Intermediate',
    description: 'Trapping one of opponent legs between your two legs while maintaining active frames (knee shield) to prevent being flattened out and initiate sweeps.',
    steps: [
      {
        phase: 'Get on Your Hip',
        instruction: 'Never stay flat on your back. Turn 90 degrees onto your bottom hip facing your opponent.',
        keyCue: 'Flat back is the enemy in half guard.'
      },
      {
        phase: 'Insert Knee Shield',
        instruction: 'Place top knee across opponent chest like a rigid diagonal barrier. Collar tie or post with top hand.',
        keyCue: 'Knee shield prevents opponent from establishing crossface.'
      },
      {
        phase: 'Underhook Dogfight Entry',
        instruction: 'Collapse knee shield when opponent pressures, shoot deep underhook, and come up to knees in dogfight position.',
        keyCue: 'High underhook allows you to take their back or sweep to top.'
      }
    ],
    commonMistakes: [
      { mistake: 'Allowing top player to secure a deep crossface and flatten your shoulders', fix: 'Protect neck with top frame; tuck chin into top shoulder.' },
      { mistake: 'Losing bottom leg lock', fix: 'Figure-four (lockdown) or tight ankle hook on their shin.' }
    ],
    relatedTechniqueIds: ['bjj-closed-guard', 'bjj-side-control', 'bjj-back-take'],
    imageKey: 'bjj',
    videoYoutubeId: '5ALqUk9uefk',
    externalResourceUrl: 'https://www.youtube.com/watch?v=5ALqUk9uefk',
    externalResourceTitle: 'Half Guard & Knee Shield Control - Stephan Kesting',
    drillSuggestion: 'Dogfight sparring: Start from half guard underhook, wrestle up to takedown.'
  },
  {
    id: 'bjj-side-control',
    name: 'Side Control Top & Heavy Pressure',
    discipline: 'BJJ',
    category: 'Pins / Dominant Positions',
    difficulty: 'Beginner',
    description: 'Perpendicular chest-to-chest pin neutralizing bottom player hips, securing crossface and far underhook to establish complete control and hunt submissions.',
    steps: [
      {
        phase: 'Crossface & Far Underhook',
        instruction: 'Wrap near arm under opponent neck, driving shoulder into their jaw (shoulder of justice) to turn their head away.',
        keyCue: 'Turning their head disables their ability to bridge towards you.'
      },
      {
        phase: 'Far Underhook & Base',
        instruction: 'Swim far hand under opponent far armpit to block their frame and isolate their upper torso.',
        keyCue: 'Keep knees wide and hips low to the canvas.'
      },
      {
        phase: 'Pressure & Transition',
        instruction: 'Transfer weight through chest sternum, ready to step into full mount or north-south.',
        keyCue: 'Breathe smoothly and maintain constant downward gravitational pressure.'
      }
    ],
    commonMistakes: [
      { mistake: 'Carrying weight on knees instead of opponent chest', fix: 'Lift knees slightly or spread wide so all 100% of bodyweight rests on their lungs.' },
      { mistake: 'Leaving near elbow open for bottom player to insert guard knee', fix: 'Glue near knee to opponent hip at all times.' }
    ],
    relatedTechniqueIds: ['bjj-mount', 'bjj-half-guard', 'mma-gnp'],
    imageKey: 'bjj',
    videoYoutubeId: '5ALqUk9uefk',
    externalResourceUrl: 'https://www.youtube.com/watch?v=5ALqUk9uefk',
    externalResourceTitle: 'How to Escape Tight Side Control - Stephan Kesting',
    drillSuggestion: 'Side control retention: Bottom player tries to shrimp for 2 minutes.'
  },
  {
    id: 'bjj-mount',
    name: 'Full Mount Control & Posture',
    discipline: 'BJJ',
    category: 'Pins / Dominant Positions',
    difficulty: 'Intermediate',
    description: 'Sitting straddled over opponent torso with knees tight to armpits (high mount) or hips low with grapevines, completely dominating the fight.',
    steps: [
      {
        phase: 'Base & Arm Posts',
        instruction: 'Place knees wide on either side of ribs, posting hands wide in a tripod to absorb bucking and bridges.',
        keyCue: 'Ride the bucking wave rather than tensing up.'
      },
      {
        phase: 'High Mount Slide',
        instruction: 'Work knees progressively up into opponent armpits, isolating their arms above their head.',
        keyCue: 'High mount negates hip bridges completely.'
      },
      {
        phase: 'Attack Selection',
        instruction: 'Threaten mounted triangle, armbar, or ground-and-pound strikes from safety.',
        keyCue: 'Never lean too far forward without base.'
      }
    ],
    commonMistakes: [
      { mistake: 'Staying in low mount while opponent bridges aggressively (gets rolled)', fix: 'Slide into high mount where bridges cannot reach your center of gravity.' },
      { mistake: 'Crossing feet under opponent back where they can ankle lock you', fix: 'Grapevine legs or pinch knees tight into armpits.' }
    ],
    relatedTechniqueIds: ['bjj-side-control', 'bjj-back-take', 'mma-gnp'],
    imageKey: 'bjj',
    videoYoutubeId: 'ygfnLjP6YQU',
    externalResourceUrl: 'https://www.youtube.com/watch?v=ygfnLjP6YQU',
    externalResourceTitle: 'High-Level Sidemount & Mount Escape - Stephan Kesting',
    drillSuggestion: 'Mount survival drill: 3 minutes maintaining mount against active bridges.'
  },
  {
    id: 'bjj-back-take',
    name: 'Back Control & Seatbelt Grip',
    discipline: 'BJJ',
    category: 'Control / Highest Value Position',
    difficulty: 'Intermediate',
    description: 'The pinnacle position in grappling and MMA. Positioning behind opponent shoulders with two hooks inside thighs and a seatbelt grip, leaving them with zero offensive options.',
    steps: [
      {
        phase: 'Seatbelt Harness',
        instruction: 'Wrap one arm over opponent shoulder (strangling arm) and one arm under their opposite armpit (control arm). Gable grip hands together.',
        keyCue: 'Strangling arm hand covers the control arm hand for protection.'
      },
      {
        phase: 'Insert Both Hooks',
        instruction: 'Hook your heels into opponent inner thighs without crossing your ankles.',
        keyCue: 'Crossing ankles on the back allows opponent to execute a painful counter footlock.'
      },
      {
        phase: 'Chest-to-Back Glue',
        instruction: 'Glue your chest directly to their spine, resting your chin on the overhook side shoulder.',
        keyCue: 'Follow their roll; maintain chest contact like a backpack.'
      }
    ],
    commonMistakes: [
      { mistake: 'Crossing feet across opponent waist (fatal footlock trap)', fix: 'Keep heels flared out into thighs; never cross ankles.' },
      { mistake: 'Losing chest contact by leaning backwards', fix: 'Stay tight against their shoulder blades.' }
    ],
    relatedTechniqueIds: ['bjj-mount', 'bjj-turtle'],
    imageKey: 'bjj',
    videoYoutubeId: '176SLdBhj_A',
    externalResourceUrl: 'https://www.youtube.com/watch?v=176SLdBhj_A',
    externalResourceTitle: 'A Rear Naked Choke Tutorial - Stephan Kesting',
    drillSuggestion: 'Rear naked choke setup flow: Hand fighting to clean neck bite.'
  },
  {
    id: 'bjj-elbow-escape',
    name: 'Elbow-Knee Escape (Shrimping from Mount/Side)',
    discipline: 'BJJ',
    category: 'Escapes / Fundamentals',
    difficulty: 'Beginner',
    description: 'The essential escape technique in Brazilian Jiu-Jitsu. Creating space with forearm frames and sliding knee to touch elbow to recover guard.',
    steps: [
      {
        phase: 'Frame Alignment',
        instruction: 'Place one forearm across opponent hip bone and other forearm across neck or bicep.',
        keyCue: 'Never push with straight arms; use skeletal frames.'
      },
      {
        phase: 'Bridge & Shrimp',
        instruction: 'Bridge hips up explosively to create space, then hip-escape (shrimp) your butt backwards towards your heels.',
        keyCue: 'Move your hips away from opponent, not opponent away from you.'
      },
      {
        phase: 'Knee-Elbow Connection',
        instruction: 'Slide your bottom knee through the gap until knee touches your elbow, recovering half guard or full guard.',
        keyCue: 'Connect knee to elbow to close the door against their counter pass.'
      }
    ],
    commonMistakes: [
      { mistake: 'Pushing with flat palms and extended arms (leads directly to armbars)', fix: 'Keep elbows tucked to ribs and frame with rigid forearms.' },
      { mistake: 'Trying to shrimp while flat on your back', fix: 'Turn onto your side before hip escaping.' }
    ],
    relatedTechniqueIds: ['bjj-closed-guard', 'bjj-half-guard'],
    imageKey: 'bjj',
    videoYoutubeId: 'ygfnLjP6YQU',
    externalResourceUrl: 'https://www.youtube.com/watch?v=ygfnLjP6YQU',
    externalResourceTitle: 'Elbow-Knee Escape (Shrimping from Mount) - Stephan Kesting',
    drillSuggestion: 'Shrimping warm-up: 50 side-to-side shrimping repetitions across mat.'
  },

  // ---------------- MMA SPECIFIC ----------------
  {
    id: 'mma-cage-wallwalk',
    name: 'Cage Wall Walk & Takedown Defense',
    discipline: 'MMA',
    category: 'MMA Fundamentals / Cage Work',
    difficulty: 'Intermediate',
    description: 'Using the octagon cage fence as an elevator to stand up from bottom pins or defend single/double leg drives with whizzers and posture.',
    steps: [
      {
        phase: 'Back to the Fence',
        instruction: 'Scoot your shoulders and hips immediately until your spine is flat against the fence chain-link.',
        keyCue: 'The cage prevents opponent from getting behind you.'
      },
      {
        phase: 'Head Posture & Base',
        instruction: 'Dig your forehead under opponent chin, establishing a strong whizzer (overhook) on the attack side.',
        keyCue: 'Keep head higher than opponent head.'
      },
      {
        phase: 'Feet Walk Up',
        instruction: 'Post hands on canvas and walk feet back underneath your hips, sliding your spine up the fence into standing position.',
        keyCue: 'Once standing, widen base and circle off the fence.'
      }
    ],
    commonMistakes: [
      { mistake: 'Staying flat in the center of the mat instead of heading to cage', fix: 'In MMA, sprint your hips to the fence immediately when taken down.' },
      { mistake: 'Grabbing the chain-link fence with fingers (illegal and risks broken fingers)', fix: 'Push with open palms; never interlock fingers in the wire.' }
    ],
    relatedTechniqueIds: ['wrest-sprawl', 'mma-gnp'],
    imageKey: 'hero',
    videoYoutubeId: 'EgfYvACoxdQ',
    externalResourceUrl: 'https://www.youtube.com/watch?v=EgfYvACoxdQ',
    externalResourceTitle: 'Tricks to Use the Cage in MMA - fightTIPS',
    drillSuggestion: 'Wall walk intervals: 5 reps from bottom side against the cage back to feet.'
  },
  {
    id: 'mma-gnp',
    name: 'Ground-and-Pound Mechanics',
    discipline: 'MMA',
    category: 'MMA Fundamentals / Striking on Ground',
    difficulty: 'Intermediate',
    description: 'Effective striking from dominant ground positions without getting caught in submissions, controlling opponent wrists while dropping heavy elbows and hammerfists.',
    steps: [
      {
        phase: 'Postural Dominance',
        instruction: 'Establish posture: sit back on heels or clamp opponent wrists to their ribs to deny upkicks.',
        keyCue: 'Never strike while leaning recklessly forward into an open guard.'
      },
      {
        phase: 'Wrist Pin & Frame',
        instruction: 'Pin opponent wrist to the canvas with one hand, creating a free runway for strikes with the other.',
        keyCue: 'Control their defense first before throwing power.'
      },
      {
        phase: 'Short Elbows & Hammerfists',
        instruction: 'Drop short, vertical elbows and hammerfists that do not require wide wind-ups that allow escapes.',
        keyCue: 'Short strikes maximize impact while keeping hips stable.'
      }
    ],
    commonMistakes: [
      { mistake: 'Winding up large swinging punches that expose you to armbars and triangles', fix: 'Keep strikes inside a 12-inch corridor; use short elbows and hammerfists.' },
      { mistake: 'Focusing 100% on striking and losing positional control', fix: 'Position before submission, and position before ground-and-pound.' }
    ],
    relatedTechniqueIds: ['bjj-mount', 'bjj-side-control', 'mt-elbow'],
    imageKey: 'striking',
    videoYoutubeId: 'EgfYvACoxdQ',
    externalResourceUrl: 'https://www.youtube.com/watch?v=EgfYvACoxdQ',
    externalResourceTitle: 'Ground and Pound Striking Posture - fightTIPS',
    drillSuggestion: 'Heavy bag ground strikes: 3 rounds x 3 min of mount transitions and strikes.'
  },
  {
    id: 'mma-feint-overhand',
    name: 'Level-Change Feint to Overhand Right',
    discipline: 'MMA',
    category: 'MMA Fundamentals / Striking Transitions',
    difficulty: 'Advanced',
    description: 'The signature MMA knockout setup. Faking a wrestling takedown level-change to freeze opponent hands and drop their guard, looping a devastating overhand over top.',
    steps: [
      {
        phase: 'Takedown Threat Establishment',
        instruction: 'Show early wrestling shots in rounds 1-2 so opponent is conditioned to drop hands to sprawl.',
        keyCue: 'The feint only works if the takedown threat is real.'
      },
      {
        phase: 'The Level Drop & Eyes Down',
        instruction: 'Drop your hips 6 inches, look directly at opponent thighs, and take a quick half-penetration step.',
        keyCue: 'Opponent hands will naturally drop to protect legs.'
      },
      {
        phase: 'Unleash Looping Overhand',
        instruction: 'Explode up and loop your rear overhand punch right over top of their dropped lead shoulder onto their jaw.',
        keyCue: 'Step lead foot 45 degrees outside to clear their potential counter.'
      }
    ],
    commonMistakes: [
      { mistake: 'Telegraphing the strike by cocking hand back', fix: 'Let the upward drive of your hips propel the punch.' },
      { mistake: 'Looking up too early during the feint', fix: 'Sell the takedown with your eyes focused on their waist.' }
    ],
    relatedTechniqueIds: ['wrest-level-change', 'box-cross'],
    imageKey: 'hero',
    videoYoutubeId: 'sK-6Ujp3KYY',
    externalResourceUrl: 'https://www.youtube.com/watch?v=sK-6Ujp3KYY',
    externalResourceTitle: 'Level-Change Feint to Overhand Right - Tony Jeffries',
    drillSuggestion: 'Feint drilling: Feint shot -> Overhand -> Takedown follow-up.'
  },
  {
    id: 'mma-cage-cutoff',
    name: 'Octagon Cage Cut-Off & Pressure',
    discipline: 'MMA',
    category: 'MMA Fundamentals / Ring Generalship',
    difficulty: 'Intermediate',
    description: 'Denying opponent escape routes through small diagonal lateral steps, herding them backward until their shoulders touch the fence where striking accuracy increases 40%.',
    steps: [
      {
        phase: 'Lateral Step Matching',
        instruction: 'Never chase opponent in straight lines. If they circle left, step diagonally left to cut their escape route.',
        keyCue: 'Step with outside foot first; stay wide and athletic.'
      },
      {
        phase: 'Teep & Lead Hook Herding',
        instruction: 'Fire lead hooks on their circling side and teeps down the center to funnel them into the dead zone.',
        keyCue: 'Use strikes as walls to guide their movement.'
      },
      {
        phase: 'Trap at the Fence',
        instruction: 'Once opponent is within 3 feet of fence, shorten distance and unleash combinations or clinch.',
        keyCue: 'Do not rush in wildly; maintain cage trap.'
      }
    ],
    commonMistakes: [
      { mistake: 'Following directly behind opponent like a dog chasing a car', fix: 'Move laterally to cut off chords of the circle, not the circumference.' },
      { mistake: 'Crossing feet while moving laterally', fix: 'Push off trailing foot; maintain wide athletic base.' }
    ],
    relatedTechniqueIds: ['box-pivot', 'mt-low-kick'],
    imageKey: 'hero',
    videoYoutubeId: '5IHQpcz-Qq8',
    externalResourceUrl: 'https://www.youtube.com/watch?v=5IHQpcz-Qq8',
    externalResourceTitle: 'Shane Fazen on How to Keep Fight Standing - fightTIPS',
    drillSuggestion: 'Cage perimeter footwork: 3 rounds shadowing opponent along fence boundary.'
  }
];

// ----------------------------------------------------
// BJJ POSITIONS EXPLORER DATA
// ----------------------------------------------------
export const BJJ_POSITIONS: BjjPosition[] = [
  {
    id: 'pos-closed-guard',
    name: 'Closed Guard',
    type: 'Neutral / Guard',
    description: 'Bottom practitioner wraps their legs completely around the opponent torso, locking ankles behind the lower back. Neutral in point scoring, but heavily offensive for bottom fighter.',
    keyConcepts: [
      'Break opponent posture using knee pulls and collar grips.',
      'Maintain active hips—do not rest flat on the mat.',
      'Keep ankles crossed high near opponent kidney line.',
      'Control wrists to deny ground-and-pound strikes.'
    ],
    offensiveOptions: [
      { name: 'Triangle Choke', type: 'Submission', description: 'Trap one arm in, one arm out; figure-four legs around head.', difficulty: 'Intermediate' },
      { name: 'Straight Armbar', type: 'Submission', description: 'Pivot 90 degrees perpendicular, clamp leg over face, extend hips.', difficulty: 'Beginner' },
      { name: 'Kimura Shoulder Lock', type: 'Submission', description: 'Figure-four grip on far wrist and rotate shoulder outward.', difficulty: 'Beginner' },
      { name: 'Scissor Sweep', type: 'Sweep', description: 'Shin across belly, scissor legs to reverse opponent onto back.', difficulty: 'Beginner' },
      { name: 'Hip Bump Sweep', type: 'Sweep', description: 'Sit up when opponent postures, drive hips into their chest to reverse.', difficulty: 'Intermediate' }
    ],
    defensiveOptions: [
      { name: 'Postural Spine Alignment', type: 'Posture', description: 'Keep hands on opponent floating ribs, look up at ceiling, do not bend neck.', difficulty: 'Beginner' },
      { name: 'Standing Guard Break', type: 'Escape', description: 'Stand up one foot at a time, push down on knee to pop ankles apart.', difficulty: 'Intermediate' },
      { name: 'Combat Base Open', type: 'Escape', description: 'Slide one knee into the tailbone and angle hips back to break lock.', difficulty: 'Beginner' }
    ],
    transitions: [
      { toPositionId: 'pos-open-guard', description: 'Open ankles to establish distance frames, spider guard, or De La Riva', direction: 'Neutral' },
      { toPositionId: 'pos-half-guard', description: 'Top player forces one leg through while passing', direction: 'Bottom' },
      { toPositionId: 'pos-mount', description: 'Bottom player executes hip bump sweep directly into full mount', direction: 'Top' }
    ],
    proTip: 'In MMA, never let the top fighter stand tall in closed guard—their downward punches carry devastating gravity assist.',
    imageKey: 'bjj'
  },
  {
    id: 'pos-open-guard',
    name: 'Open Guard (De La Riva & Butterfly)',
    type: 'Neutral / Guard',
    description: 'Bottom fighter keeps legs unlocked, using feet planted on opponent hips, biceps, or wrapped around legs (De La Riva hook) to manage distance and off-balance.',
    keyConcepts: [
      'Maintain 4 points of contact at all times (2 feet, 2 hands).',
      'Never allow top player to control both pant cuffs simultaneously.',
      'Keep your feet actively pushing and pulling like shock absorbers.',
      'Look for elevated butterfly hooks to launch overhead sweeps.'
    ],
    offensiveOptions: [
      { name: 'De La Riva Sickle Sweep', type: 'Sweep', description: 'Hook outside of lead leg, pull sleeve, kick far ankle.', difficulty: 'Intermediate' },
      { name: 'Butterfly Elevator Sweep', type: 'Sweep', description: 'Instep hook under thigh, overhook far arm, elevate directly to mount.', difficulty: 'Intermediate' },
      { name: 'Omoplata Shoulder Lock', type: 'Submission', description: 'Kick leg over shoulder, sit up, apply rotational leverage to shoulder.', difficulty: 'Advanced' },
      { name: 'Tripod Sweep', type: 'Sweep', description: 'Foot on hip, hand grips heel, push-pull to drop opponent backward.', difficulty: 'Beginner' }
    ],
    defensiveOptions: [
      { name: 'Toreando Guard Pass', type: 'Escape', description: 'Grip both knees, push legs to one side, sprint into side control.', difficulty: 'Beginner' },
      { name: 'Knee Slice Pass', type: 'Escape', description: 'Slide lead shin diagonally across thigh into underhook side control.', difficulty: 'Intermediate' }
    ],
    transitions: [
      { toPositionId: 'pos-closed-guard', description: 'Pull opponent back into closed guard when they attempt to disengage', direction: 'Neutral' },
      { toPositionId: 'pos-half-guard', description: 'Trap one leg as opponent initiates a knee slice pass', direction: 'Bottom' },
      { toPositionId: 'pos-side-control', description: 'Top player clears legs and settles into side control', direction: 'Top' }
    ],
    proTip: 'Open guard requires high hip mobility. If opponent attempts to disengage and stand, use technical stand-up immediately.',
    imageKey: 'bjj'
  },
  {
    id: 'pos-half-guard',
    name: 'Half Guard & Knee Shield',
    type: 'Neutral / Guard',
    description: 'Bottom practitioner isolates one of top opponent legs between their own legs, maintaining knee shield or underhook. The battleground for MMA ground transitions.',
    keyConcepts: [
      'Never stay flat on your back; stay on bottom hip.',
      'Battle for the underhook—whoever gets the underhook usually wins half guard.',
      'Use knee shield frame to protect your neck from crossface pressure.',
      'Keep head tucked under opponent chin.'
    ],
    offensiveOptions: [
      { name: 'Dogfight Back Take', type: 'Transition', description: 'Underhook up to knees, wrap waist, slip behind for hooks.', difficulty: 'Intermediate' },
      { name: 'Old School Sweep', type: 'Sweep', description: 'Reach behind to grab far toe, elevate and roll opponent onto back.', difficulty: 'Intermediate' },
      { name: 'Kimura from Bottom Half', type: 'Submission', description: 'Attack bent arm when top player posts hand on mat.', difficulty: 'Intermediate' },
      { name: 'Ground Strikes (Top)', type: 'Strike', description: 'Top player postures with head pin and drops short elbows.', difficulty: 'Beginner' }
    ],
    defensiveOptions: [
      { name: 'Crossface & Whizzer (Top)', type: 'Posture', description: 'Drive shoulder into bottom jaw to turn their head and flatten hips.', difficulty: 'Beginner' },
      { name: 'Whizzer Counter & Sprawl', type: 'Escape', description: 'Top player uses overhook to nullify bottom dogfight sweep.', difficulty: 'Intermediate' }
    ],
    transitions: [
      { toPositionId: 'pos-closed-guard', description: 'Shrimp hips back and slide trapped leg through into closed guard', direction: 'Bottom' },
      { toPositionId: 'pos-side-control', description: 'Top player slides trapped knee free into side control', direction: 'Top' },
      { toPositionId: 'pos-back-control', description: 'Bottom player secures dogfight underhook and climbs onto back', direction: 'Top' }
    ],
    proTip: 'MMA legends like Khabib Nurmagomedov use top half guard to triangle-lock bottom opponent legs against the cage for brutal ground-and-pound.',
    imageKey: 'bjj'
  },
  {
    id: 'pos-side-control',
    name: 'Side Control',
    type: 'Dominant Top',
    description: 'Top player is positioned perpendicular across bottom opponent chest, pinning their shoulders to the mat while controlling neck and far armpit.',
    keyConcepts: [
      'Crossface shoulder pressure controls bottom player head direction.',
      'Underhook far arm prevents bottom player from turning into turtle.',
      'Drop hips low with wide knee base or scarf-hold switch.',
      'Bottom player must frame with forearms; never push with flat hands.'
    ],
    offensiveOptions: [
      { name: 'Americana Keylock', type: 'Submission', description: 'Pin near wrist to mat, slide arm underneath elbow, rotate upward.', difficulty: 'Beginner' },
      { name: 'Kimura Shoulder Lock', type: 'Submission', description: 'Trap far arm wrist and crank behind opponent back.', difficulty: 'Intermediate' },
      { name: 'Straight Armbar from Top', type: 'Submission', description: 'Step near leg over head, isolate extended arm, fall back.', difficulty: 'Intermediate' },
      { name: 'Knee on Belly Pop', type: 'Transition', description: 'Drive near knee onto solar plexus for intense pressure and striking.', difficulty: 'Intermediate' }
    ],
    defensiveOptions: [
      { name: 'Elbow-Knee Escape (Shrimp)', type: 'Escape', description: 'Frame forearm on hip, bridge, shrimp hips out, insert bottom knee.', difficulty: 'Beginner' },
      { name: 'Underhook Turn to Turtle', type: 'Escape', description: 'Dig inside underhook, bridge into opponent, turn onto knees.', difficulty: 'Intermediate' },
      { name: 'Harpoon / Roll Sweep', type: 'Sweep', description: 'Trap opponent far arm when they reach, bridge diagonally over shoulder.', difficulty: 'Advanced' }
    ],
    transitions: [
      { toPositionId: 'pos-mount', description: 'Slide near knee smoothly across opponent stomach into full mount', direction: 'Top' },
      { toPositionId: 'pos-turtle', description: 'Bottom player turns away to belly to avoid punches', direction: 'Neutral' },
      { toPositionId: 'pos-half-guard', description: 'Bottom player sneaks knee in and captures one leg', direction: 'Bottom' }
    ],
    proTip: 'In MMA, side control is the premier position to deliver short knees to the ribs and downward elbows to the facial structure.',
    imageKey: 'bjj'
  },
  {
    id: 'pos-mount',
    name: 'Full Mount',
    type: 'Dominant Top',
    description: 'Top practitioner sits straddling the torso of the opponent. 4 points under BJJ scoring rules and the most terrifying striking platform in MMA.',
    keyConcepts: [
      'Keep knees wide or slide high under opponent armpits.',
      'Post hands in wide tripod to cushion aggressive bucking.',
      'Isolate opponent elbows away from their ribcage.',
      'Bottom player must bridge diagonally, never straight up.'
    ],
    offensiveOptions: [
      { name: 'Mounted Armbar', type: 'Submission', description: 'Slide knee high, pivot 90 degrees, swing leg over face.', difficulty: 'Intermediate' },
      { name: 'Mounted Triangle', type: 'Submission', description: 'Thread shin under neck and lock legs while mounted.', difficulty: 'Advanced' },
      { name: 'Ground-and-Pound Barrage', type: 'Strike', description: 'Post on forehead with one hand, drop heavy vertical hammerfists.', difficulty: 'Beginner' },
      { name: 'Ezekiel Choke', type: 'Submission', description: 'Sleeve/wrist wrap around neck with fist driven into windpipe.', difficulty: 'Intermediate' }
    ],
    defensiveOptions: [
      { name: 'Upa Bridge & Roll (Trap & Roll)', type: 'Escape', description: 'Trap same-side arm and foot, explosive diagonal bridge to reverse.', difficulty: 'Beginner' },
      { name: 'Elbow Escape to Half Guard', type: 'Escape', description: 'Frame on knee, flat turn to side, wiggle knee through into half guard.', difficulty: 'Beginner' },
      { name: 'Kip Escape', type: 'Escape', description: 'Slide knees straight up under opponent hips and pop legs into butterfly.', difficulty: 'Advanced' }
    ],
    transitions: [
      { toPositionId: 'pos-back-control', description: 'Opponent turns belly down to escape punches, giving up back hooks', direction: 'Top' },
      { toPositionId: 'pos-side-control', description: 'Top player steps off to side control to tighten an arm submission', direction: 'Top' },
      { toPositionId: 'pos-closed-guard', description: 'Bottom player executes successful bridge and roll into top guard', direction: 'Bottom' }
    ],
    proTip: 'High mount (knees in the armpits) completely nullifies the bottom player bridge power because your hips are above their levers.',
    imageKey: 'bjj'
  },
  {
    id: 'pos-back-control',
    name: 'Back Control (Back Mount)',
    type: 'Back Mount',
    description: 'Top practitioner attaches to the opponent back like a backpack with both heel hooks inside thighs and a seatbelt grip around chest. The highest percentage submission spot in combat history.',
    keyConcepts: [
      'Strangling arm goes over the shoulder; control arm goes under armpit.',
      'Never cross ankles across opponent abdomen (leaves open to ankle lock).',
      'Keep your chest glued to their spine at all times.',
      'Follow opponent if they roll from left to right.'
    ],
    offensiveOptions: [
      { name: 'Rear-Naked Choke (Mata Leão)', type: 'Submission', description: 'Forearm under chin, biceps grip, palm behind head, inflate chest.', difficulty: 'Beginner' },
      { name: 'Short Choke', type: 'Submission', description: 'Blade of wrist across trachea with palm-to-palm grip.', difficulty: 'Beginner' },
      { name: 'Bow & Arrow Choke (Gi)', type: 'Submission', description: 'Collar grip with far knee hook, arch back like shooting an arrow.', difficulty: 'Intermediate' },
      { name: 'Body Triangle Lock', type: 'Posture', description: 'Figure-four legs around waist to crush diaphragm and restrict breathing.', difficulty: 'Intermediate' }
    ],
    defensiveOptions: [
      { name: 'Two-on-One Hand Fight', type: 'Escape', description: 'Grab strangling wrist with both hands immediately to keep chin tucked.', difficulty: 'Beginner' },
      { name: 'Scoot Hips Off Centerline', type: 'Escape', description: 'Slide hips to the underhook side and put shoulder blades on mat.', difficulty: 'Intermediate' },
      { name: 'Turn into Guard', type: 'Escape', description: 'Clear near hook, pivot chest 180 degrees to face opponent in guard.', difficulty: 'Intermediate' }
    ],
    transitions: [
      { toPositionId: 'pos-mount', description: 'Opponent rolls to face you and you transition straight into full mount', direction: 'Top' },
      { toPositionId: 'pos-turtle', description: 'Opponent rolls belly down while defending hooks', direction: 'Neutral' },
      { toPositionId: 'pos-closed-guard', description: 'Bottom player slips shoulders to mat and recovers closed guard', direction: 'Bottom' }
    ],
    proTip: '90% of MMA fighters who secure back control with more than 2 minutes on the clock either submit the opponent or earn a referee stoppage.',
    imageKey: 'bjj'
  },
  {
    id: 'pos-turtle',
    name: 'Turtle Position',
    type: 'Inferior Bottom',
    description: 'Fighter is on hands and knees with elbows tucked into thighs and head lowered. Common defensive refuge after failed takedowns or to prevent guard passes.',
    keyConcepts: [
      'Keep elbows and knees glued together to deny hooks.',
      'Protect neck with tight chin tuck and hands guarding collar/throat.',
      'Do not remain static; explode immediately to stand up or roll.',
      'Top player looks to insert hooks or snap down into front headlock.'
    ],
    offensiveOptions: [
      { name: 'Granby Roll', type: 'Escape', description: 'Shoulder roll across the mat to invert and recover full guard.', difficulty: 'Intermediate' },
      { name: 'Peterson Roll / Sit-Through', type: 'Sweep', description: 'Trap opponent wrist, sit out, and roll them across your hips.', difficulty: 'Intermediate' },
      { name: 'Bulldog / Clock Choke (Top)', type: 'Submission', description: 'Top player grips collar or neck and walks around like hands of clock.', difficulty: 'Intermediate' },
      { name: 'Peruvian Necktie / Anaconda (Top)', type: 'Submission', description: 'Front headlock arm-in strangle rolling opponent over.', difficulty: 'Advanced' }
    ],
    defensiveOptions: [
      { name: 'Quadpod Standup (MMA)', type: 'Escape', description: 'Pop up onto four feet, back into the cage, and stand up.', difficulty: 'Beginner' },
      { name: 'Peel Far Hook', type: 'Escape', description: 'Reach back to push opponent incoming heel away before it locks.', difficulty: 'Beginner' }
    ],
    transitions: [
      { toPositionId: 'pos-back-control', description: 'Top player inserts both hooks and secures seatbelt grip', direction: 'Top' },
      { toPositionId: 'pos-side-control', description: 'Top player breaks down turtle arms to flatten opponent onto back', direction: 'Top' },
      { toPositionId: 'pos-closed-guard', description: 'Bottom player executes Granby roll or sit-through back into guard', direction: 'Bottom' }
    ],
    proTip: 'In modern MMA, turtle is heavily preferred over staying flat on your back in guard because it allows the athlete to explode directly up against the fence.',
    imageKey: 'wrestling'
  }
];

// ----------------------------------------------------
// DAILY CHALLENGES & ACHIEVEMENTS DATA
// ----------------------------------------------------
export const INITIAL_DAILY_CHALLENGES: DailyChallenge[] = [
  {
    id: 'dc-1',
    title: 'The Piston 100',
    discipline: 'Boxing',
    description: 'Throw 100 crisp lead jabs focusing on chin tuck and shoulder height.',
    targetCount: 100,
    unit: 'Jabs',
    xp: 150,
    completed: false
  },
  {
    id: 'dc-2',
    title: 'Sprawl Reflex Test',
    discipline: 'Wrestling',
    description: 'Execute 30 explosive sprawls kicking both hips completely to the floor.',
    targetCount: 30,
    unit: 'Sprawls',
    xp: 200,
    completed: false
  },
  {
    id: 'dc-3',
    title: 'Championship Round',
    discipline: 'MMA',
    description: 'Complete one 5-minute continuous round of MMA shadowboxing with striking & level changes.',
    targetCount: 5,
    unit: 'Minutes',
    xp: 250,
    completed: true
  }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach-first-technique',
    title: 'First Step on the Mat',
    description: 'Learn and review your first technique in the MMA library.',
    icon: 'BookOpen',
    category: 'Technique',
    progress: 1,
    maxProgress: 1,
    unlocked: true,
    unlockedDate: 'Oct 24, 2026'
  },
  {
    id: 'ach-first-session',
    title: 'First Sweat Logged',
    description: 'Complete and record your first training timer session.',
    icon: 'Timer',
    category: 'Training',
    progress: 1,
    maxProgress: 1,
    unlocked: true,
    unlockedDate: 'Oct 25, 2026'
  },
  {
    id: 'ach-master-10',
    title: 'Arsenal Builder',
    description: 'Mark 10 different MMA techniques as mastered.',
    icon: 'Award',
    category: 'Mastery',
    progress: 4,
    maxProgress: 10,
    unlocked: false
  },
  {
    id: 'ach-train-10',
    title: 'Gym Regular',
    description: 'Complete 10 round timer or shadowbox sessions.',
    icon: 'Dumbbell',
    category: 'Training',
    progress: 6,
    maxProgress: 10,
    unlocked: false
  },
  {
    id: 'ach-train-50',
    title: 'Iron Veteran',
    description: 'Complete 50 training sessions in FightLab.',
    icon: 'Shield',
    category: 'Training',
    progress: 6,
    maxProgress: 50,
    unlocked: false
  },
  {
    id: 'ach-first-ai-analysis',
    title: 'AI Lab Biometrics',
    description: 'Run your first shadowboxing biomechanical scan.',
    icon: 'Cpu',
    category: 'AI Analysis',
    progress: 1,
    maxProgress: 1,
    unlocked: true,
    unlockedDate: 'Oct 28, 2026'
  },
  {
    id: 'ach-bjj-explorer',
    title: 'Grappling Cartographer',
    description: 'Inspect all 7 core Brazilian Jiu-Jitsu positions in the explorer.',
    icon: 'Compass',
    category: 'Mastery',
    progress: 5,
    maxProgress: 7,
    unlocked: false
  },
  {
    id: 'ach-well-rounded',
    title: 'Complete Mixed Martial Artist',
    description: 'Master at least one technique in Boxing, Muay Thai, Wrestling, BJJ, and MMA.',
    icon: 'Zap',
    category: 'Technique',
    progress: 3,
    maxProgress: 5,
    unlocked: false
  }
];
